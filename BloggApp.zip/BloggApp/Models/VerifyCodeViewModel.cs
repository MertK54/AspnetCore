namespace BloggApp.Models
{

public class VerifyCodeViewModel
{
    public string? Email { get; set; }
    public string? Code { get; set; }
}
}

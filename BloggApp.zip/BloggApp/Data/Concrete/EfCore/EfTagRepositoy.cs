using BloggApp.Data.Abstract;
using BloggApp.Data.Concrete.EfCore;
using BloggApp.Entity;
using Microsoft.EntityFrameworkCore;

namespace BloggApp.Data.Concrete
{
    public class EfTagRepositoy : ITagRepository
    {
        private BlogContext _context;
        public EfTagRepositoy(BlogContext context)
        {
            _context = context;
        }
        public IQueryable<Tag> Tags => _context.Tags;

        public void CreateTag(Tag Tag)
        {
            _context.Tags.Add(Tag);
            _context.SaveChanges();
        }
        public async Task<List<Tag>> GetTagsByIds(int[] tagIds)
        {
            return await _context.Tags
                                .Where(tag => tagIds.Contains(tag.TagId))
                                .ToListAsync();
        }
    }
}